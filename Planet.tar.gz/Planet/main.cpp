#include "mainwindow.h"
#include "environment.h"
#include "time.h"
#include "distance.h"
#include "car.h"
#include "foot.h"

#include <QApplication>
#include <QWidget>



int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.display();
    w.show();
    return a.exec();
}
