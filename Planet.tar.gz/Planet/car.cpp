#include "car.h"
#include "travel_mode.h"
#include "environment.h"
#include "distance.h"

car::car()
{
    this->damage = 11;
    this->step = 15;
}

void car::travel(environment& environment, Distance& distance){
    environment.reduce_health(this->damage);
    distance.reduce_distance(this->step);
}


void car::set_damage(int damage){
    if (damage <= 0){
        return;
    }
    this->damage = damage;
}

void car::reset(){
    this->damage = 11;
    this->step = 15;
}
