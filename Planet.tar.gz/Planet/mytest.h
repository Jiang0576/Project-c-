#ifndef MYTEST_H
#define MYTEST_H

#include <QObject>

#include <QtGui>
#include <QtTest/QtTest>

class MyTest
{
    Q_OBJECT

private slots:
    void testGui();
};

#endif // MYTEST_H
