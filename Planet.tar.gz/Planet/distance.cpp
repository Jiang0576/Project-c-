#include "distance.h"

Distance::Distance()
{
    this->now_distance = 100;
    this->init_distance = 100;
}

void Distance::set_distance(int d){
    this->init_distance = d;
    this->now_distance = d;
}

float Distance::reduce_distance(int d){
    this->now_distance -= d;

    // Set to 0 if distance is less than or equal to 0.
    if (this->now_distance < 0){
        this->now_distance = 0;
    }

    return (this->init_distance - this->now_distance) * 1.0 / this->init_distance;
}

int Distance::get_now_distance(){
    return this->now_distance;
}

int Distance::get_init_distance(){
    return this->init_distance;
}

int Distance::get_ratio(){
    // The reason for multiplying by 100 is that the progress bar is in 100 units.
    return (this->init_distance - this->now_distance) * 100 / this->init_distance;
}

void Distance::reset(){
    this->now_distance = 100;
    this->init_distance = 100;
}
