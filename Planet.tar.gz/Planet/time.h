#ifndef TIME_H
#define TIME_H


class time
{
private:
    // total time
    int step;

    // remaining time
    int now_step;
public:
    time();
    time(int step);

    // operator overload --- increase time
    void operator+ (const int& time_);

    // operator overload --- reduce time
    void operator- (const int& time_);

    // get total time
    int get_init_time();

    // get remaining time
    int get_now_time();

    // set time
    void set_time(int time);

    // reset the member variables
    void reset();
};

#endif // TIME_H
