#include "mytest.h"
#include "QLineEdit"

void MyTest::testGui()
 {
     // Test whether the text box can only enter numbers.
     // If it is normal, only '111' will remain in the entered text
     QLineEdit lineEdit;
     QTest::keyClicks(&lineEdit, "Hello111World");
     QCOMPARE(lineEdit.text(), QString("111"));
 }
