#include "environment.h"

environment::environment()
{
    this->health = 100;
    this->now_health = 100;
}

bool environment::reduce_health(int h){
    this->now_health -= h;

    // Set to 0 if health is less than or equal to 0.
    if (this->now_health <= 0){
        this->now_health = 0;
    }

    return this->now_health > 0;
}

void environment::add_health(int h){
    this->now_health += h;
}

int environment::get_init_health(){
    return this->health;
}

int environment::get_now_health(){
    return this->now_health;
}

void environment::set_health(int h){
    this->health = h;
    this->now_health = h;
}
void environment::reset(){
    this->health = 100;
    this->now_health = 100;
}

