#ifndef ENVIRONMENT_H
#define ENVIRONMENT_H


class environment
{
private:
    // total health
    int health;

    // remaining health
    int now_health;
public:
    environment();

    // driving damages the environment so that it will reduce environmental health
    bool reduce_health(int h);

    // Walking helps to protect the environment so that it will improve the health of the environment
    void add_health(int h);

    // get total health of the environment
    int get_init_health();

    // get remaining health of the environment
    int get_now_health();

    // set total health and remaining health
    void set_health(int h);

    // reset the member variables
    void reset();
};

#endif // ENVIRONMENT_H
