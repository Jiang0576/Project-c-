#ifndef DISTANCE_H
#define DISTANCE_H


class Distance
{
private:
    // total distance
    int init_distance;

    // remaining distance
    int now_distance;
public:
    Distance();

    // set total distance and remaining distance
    void set_distance(int d);

    // After choosing the travel mode, the remaining distance will be reduced.
    float reduce_distance(int d);

    // get remaining distance
    int get_now_distance();

    // get total distace
    int get_init_distance();

    // Get the ratio of the remaining distance to the total distance.
    int get_ratio();

    // reset the member variables
    void reset();
};

#endif // DISTANCE_H
