#ifndef FOOT_H
#define FOOT_H

#include "travel_mode.h"

class foot : public travel_mode
{
public:
    foot();

    // travel by walking
    void travel(environment& environment, Distance& distance);

    // set the damage of walk(minus)
    void set_damage(int damage);

    // reset the member variables
    void reset();
};

#endif // FOOT_H
