#include "mainwindow.h"
#include "ui_mainwindow.h"


#include<iostream>
#include<ctype.h>
#include <sstream>

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    QIntValidator  *IntValidator = new QIntValidator(this) ;

    ui->lineEdit->setValidator(IntValidator);
    ui->lineEdit_2->setValidator(IntValidator);
    ui->lineEdit_3->setValidator(IntValidator);
    ui->lineEdit_4->setValidator(IntValidator);
    ui->lineEdit_5->setValidator(IntValidator);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Redisplay all content to the window
void MainWindow::display(){
    ui->lineEdit->setText(QString::fromStdString(to_string(car_.damage)));
    ui->lineEdit_2->setText(QString::fromStdString(to_string(foot_.damage)));
    ui->lineEdit_3->setText(QString::fromStdString(to_string(time_.get_init_time())));
    ui->lineEdit_4->setText(QString::fromStdString(to_string(distance_.get_init_distance())));
    ui->lineEdit_5->setText(QString::fromStdString(to_string(environment_.get_init_health())));
    ui->lcdNumber_3->display(time_.get_now_time());
    ui->lcdNumber->display(distance_.get_now_distance());
    ui->lcdNumber_2->display(environment_.get_now_health());
    ui->progressBar->setValue(distance_.get_ratio());
}

// START clicked
void MainWindow::on_pushButton_2_clicked()
{
    car_.set_damage(ui->lineEdit->text().toInt());
    foot_.set_damage(ui->lineEdit_2->text().toInt());
    time_.set_time(ui->lineEdit_3->text().toInt());
    distance_.set_distance(ui->lineEdit_4->text().toInt());
    environment_.set_health(ui->lineEdit_5->text().toInt());
    ui->label_10->setText(QString::fromStdString("Game Start!"));
    display();
}


// RESET clicked
void MainWindow::on_pushButton_clicked()
{
    car_.reset();
    foot_.reset();
    environment_.reset();
    time_.reset();
    distance_.reset();

    display();
    ui->label_10->setText(QString::fromStdString("Message: Please click 'START' to restart!"));
}


// CAR clicked
void MainWindow::on_button_1_clicked()
{
    // If you fail, you can't continue the game and need to start again.
    if (environment_.get_now_health() == 0 || time_.get_now_time() <= 0){
        ui->label_10->setText("Message: Game over. Please click 'RESET' to restart!");
        return;
    }

    // If you win, please restart the game.
    if (distance_.get_now_distance() <= 0){
        ui->label_10->setText(QString::fromStdString("Message: Congratulations, you won! Please try to make it more difficult."));
        on_pushButton_clicked();
        return;
    }


    car_.travel(environment_, distance_);
    time_ - 1;
    display();

    // Judge the result of this trip, success or failure?
    if (environment_.get_now_health() == 0 || time_.get_now_time() <= 0){
        ui->label_10->setText("Game over. Please click 'RESET' to restart!");
        lose_distance.push_back(distance_.get_now_distance());
    } else {
        if (distance_.get_now_distance() <= 0){
            ui->label_10->setText(QString::fromStdString("Message: Congratulations, you won! Please try to make it more difficult."));
            on_pushButton_clicked();
            win_hp.push_back(environment_.get_now_health());
            return;
        }
        stringstream ss;
        ss << "Message: Environment's HP is " << environment_.get_now_health() << ", be careful!";
        ui->label_10->setText(QString::fromStdString(ss.str()));
    }
}


// FOOT clicked
void MainWindow::on_button_2_clicked()
{
    // If you fail, you can't continue the game and need to start again.
    if (environment_.get_now_health() == 0 || time_.get_now_time() <= 0){
        ui->label_10->setText("Message: Game over. Please click 'RESET' to restart!");
        return;
    }

    // If you win, please restart the game.
    if (distance_.get_now_distance() <= 0){
        ui->label_10->setText(QString::fromStdString("Message: Congratulations, you won! Please try to make it more difficult."));
        on_pushButton_clicked();

        win_hp.push_back(environment_.get_now_health());
        return;
    }

    foot_.travel(environment_, distance_);
    display();
    time_ - 1;

    // Judge the result of this trip, success or failure?
    if (environment_.get_now_health() == 0 || time_.get_now_time() <= 0){
        ui->label_10->setText("Game over. Please click 'RESET' to restart!");
        lose_distance.push_back(distance_.get_now_distance());
    } else {
        if (distance_.get_now_distance() <= 0){
            ui->label_10->setText(QString::fromStdString("Message: Congratulations, you won! Please try to make it more difficult."));
            on_pushButton_clicked();
            return;
        }
        ui->label_10->setText(QString::fromStdString("Message: Great! But you should pay attention to time!"));
    }
}

