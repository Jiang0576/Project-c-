#ifndef CAR_H
#define CAR_H

#include "travel_mode.h"
#include "environment.h"
#include "distance.h"

// car
class car : public travel_mode
{
public:
    car();

    // travel by car
    void travel(environment& environment, Distance& distance);

    // set the damage of driving
    void set_damage(int damage);

    // reset the member variables
    void reset();
};

#endif // CAR_H
