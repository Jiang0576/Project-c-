/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLCDNumber>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QProgressBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label_4;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QProgressBar *progressBar;
    QLabel *label_10;
    QLabel *label_11;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_9;
    QLabel *label_8;
    QLabel *label_7;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout;
    QPushButton *button_1;
    QPushButton *button_2;
    QWidget *widget3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *widget4;
    QVBoxLayout *verticalLayout_4;
    QLCDNumber *lcdNumber_3;
    QLCDNumber *lcdNumber;
    QLCDNumber *lcdNumber_2;
    QMenuBar *menubar;
    QMenu *menuThere_is_no_Planet_B;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(601, 544);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(50, 210, 121, 201));
        label_4->setPixmap(QPixmap(QString::fromUtf8("static/car.png")));
        label_4->setScaledContents(true);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(370, 380, 181, 71));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(370, 24, 181, 151));
        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(370, 340, 181, 23));
        progressBar->setValue(24);
        label_10 = new QLabel(centralwidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(40, 460, 511, 17));
        label_11 = new QLabel(centralwidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(206, 216, 101, 191));
        label_11->setPixmap(QPixmap(QString::fromUtf8("static/foot.png")));
        label_11->setScaledContents(true);
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(40, 20, 170, 151));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout->addWidget(label_6);

        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout->addWidget(label_9);

        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout->addWidget(label_8);

        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout->addWidget(label_7);

        widget1 = new QWidget(centralwidget);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(210, 20, 144, 152));
        verticalLayout_2 = new QVBoxLayout(widget1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEdit = new QLineEdit(widget1);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setProperty("int", QVariant(0));

        verticalLayout_2->addWidget(lineEdit);

        lineEdit_2 = new QLineEdit(widget1);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        verticalLayout_2->addWidget(lineEdit_2);

        lineEdit_3 = new QLineEdit(widget1);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));

        verticalLayout_2->addWidget(lineEdit_3);

        lineEdit_4 = new QLineEdit(widget1);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));

        verticalLayout_2->addWidget(lineEdit_4);

        lineEdit_5 = new QLineEdit(widget1);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));

        verticalLayout_2->addWidget(lineEdit_5);

        widget2 = new QWidget(centralwidget);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        widget2->setGeometry(QRect(40, 420, 281, 27));
        horizontalLayout = new QHBoxLayout(widget2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        button_1 = new QPushButton(widget2);
        button_1->setObjectName(QString::fromUtf8("button_1"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("static/car.png"), QSize(), QIcon::Normal, QIcon::Off);
        button_1->setIcon(icon);

        horizontalLayout->addWidget(button_1);

        button_2 = new QPushButton(widget2);
        button_2->setObjectName(QString::fromUtf8("button_2"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("static/foot.png"), QSize(), QIcon::Normal, QIcon::Off);
        button_2->setIcon(icon1);

        horizontalLayout->addWidget(button_2);

        widget3 = new QWidget(centralwidget);
        widget3->setObjectName(QString::fromUtf8("widget3"));
        widget3->setGeometry(QRect(370, 220, 111, 111));
        verticalLayout_3 = new QVBoxLayout(widget3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget3);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_3->addWidget(label);

        label_2 = new QLabel(widget3);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_3->addWidget(label_2);

        label_3 = new QLabel(widget3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_3->addWidget(label_3);

        widget4 = new QWidget(centralwidget);
        widget4->setObjectName(QString::fromUtf8("widget4"));
        widget4->setGeometry(QRect(480, 220, 71, 111));
        verticalLayout_4 = new QVBoxLayout(widget4);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        lcdNumber_3 = new QLCDNumber(widget4);
        lcdNumber_3->setObjectName(QString::fromUtf8("lcdNumber_3"));

        verticalLayout_4->addWidget(lcdNumber_3);

        lcdNumber = new QLCDNumber(widget4);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));

        verticalLayout_4->addWidget(lcdNumber);

        lcdNumber_2 = new QLCDNumber(widget4);
        lcdNumber_2->setObjectName(QString::fromUtf8("lcdNumber_2"));

        verticalLayout_4->addWidget(lcdNumber_2);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 601, 27));
        menuThere_is_no_Planet_B = new QMenu(menubar);
        menuThere_is_no_Planet_B->setObjectName(QString::fromUtf8("menuThere_is_no_Planet_B"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuThere_is_no_Planet_B->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        label_4->setText(QString());
        pushButton->setText(QApplication::translate("MainWindow", "RESET", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("MainWindow", "START", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("MainWindow", "MESSAGE: ", 0, QApplication::UnicodeUTF8));
        label_11->setText(QString());
        label_5->setText(QApplication::translate("MainWindow", "<html><head/><body><p>CAR_DAMAGE</p></body></html>", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("MainWindow", "FOOT_DAMAGE(MINUS)", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("MainWindow", "TIME", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("MainWindow", "DISTANCE", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("MainWindow", "ENVIRONMENT_HEALTH", 0, QApplication::UnicodeUTF8));
        button_1->setText(QApplication::translate("MainWindow", "CAR", 0, QApplication::UnicodeUTF8));
        button_2->setText(QApplication::translate("MainWindow", "FOOT", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "TIME", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "DISTANCE", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "ENVIRONMENT", 0, QApplication::UnicodeUTF8));
        menuThere_is_no_Planet_B->setTitle(QApplication::translate("MainWindow", "There is no Planet B", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
