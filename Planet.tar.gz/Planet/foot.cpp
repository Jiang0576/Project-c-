#include "foot.h"
#include "environment.h"
#include "distance.h"

foot::foot()
{
    this->damage = -1;
    this->step = 3;
}

void foot::travel(environment& environment, Distance& distance){
    environment.reduce_health(this->damage);
    distance.reduce_distance(this->step);
}

void foot::set_damage(int damage){
    // Make sure that the damage of the foot is negative.
    if (damage > 0){
        damage *= -1;
    }

    if (damage != 0) this->damage = damage;
}

void foot::reset(){
    this->damage = -1;
    this->step = 3;
}

