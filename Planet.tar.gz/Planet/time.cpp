#include "time.h"

time::time(){
    this->step = 10;
    this->now_step = 10;
}

time::time(int step){
    this->step = step;
    this->now_step = step;
}

void time::operator+(const int &time_){
    this->now_step += time_;
}

void time::operator-(const int &time_){
    this->now_step -= time_;
}

int time::get_init_time(){
    return this->step;
}

int time::get_now_time(){
    return this->now_step;
}

void time::set_time(int time){
    this->step = time;
    this->now_step = time;
}

void time::reset(){
    this->step = 10;
    this->now_step = 10;
}
