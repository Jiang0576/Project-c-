#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "car.h"
#include "foot.h"
#include "distance.h"
#include "environment.h"
#include "time.h"
#include <vector>
#include <list>

#include <QMainWindow>
using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void display();

private slots:
    // button 'START' clicked
    void on_pushButton_2_clicked();

    // button 'RESET' clicked
    void on_pushButton_clicked();

    // button 'CAR' clicked
    void on_button_1_clicked();

    // button 'FOOT' clicked
    void on_button_2_clicked();

private:
    Ui::MainWindow *ui;
    car car_;
    foot foot_;
    environment environment_;
    Distance distance_;
    time time_;

    // The first place to use the STL library: save the remaining health at each victory.
    list<int> win_hp;

    // The second place to use the STL library: save the remaining distance for each failure.
    vector<int> lose_distance;

};
#endif // MAINWINDOW_H
