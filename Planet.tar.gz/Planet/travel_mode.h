#ifndef TRAVEL_MODE_H
#define TRAVEL_MODE_H

#include "environment.h"
#include "distance.h"

// parent class of car and foot
class travel_mode
{
public:
    // damage to the environment:Pour CAR, les dommages causés à l’environnement sont positifs. Pour FOOT, les dommages environnementaux négatifs
    int damage;

    // distance traveled per use
    int step;

    // virtual function: travel
    virtual void travel(environment& environment, Distance& distance){};

    // virtual function set_damage
    virtual void set_damage(int damage){};
};

#endif // TRAVEL_MODE_H
